package kr.moonseungjun.villageguardians.game;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

public record VillageSnapshot(
        int day,
        String phase,
        int difficultyWave,
        String mayorName,
        boolean localPlayerMayor,
        int onlinePlayers,
        int food,
        int wood,
        int stone,
        int iron,
        int residents,
        int morale,
        int wallIntegrity,
        int northGateIntegrity,
        int southGateIntegrity,
        boolean villageGenerated,
        int townHallIntegrity,
        int barracksIntegrity,
        int storehouseIntegrity,
        int infirmaryIntegrity,
        int northBarricadeCharges,
        int southBarricadeCharges,
        int workProgressPercent,
        boolean workCompleted,
        boolean localPlayerContributed,
        int workContributors,
        int guardReadiness,
        int medicalReadiness,
        int guardCount,
        boolean localDefenseVoteCast,
        int defenseVotes,
        String activeDoctrine,
        String leadingDoctrine,
        int balancedDoctrineVotes,
        int northDoctrineVotes,
        int southDoctrineVotes,
        int reserveDoctrineVotes,
        String raidForecast,
        int northSpikeCharges,
        int southSpikeCharges,
        int northGuardCount,
        int southGuardCount,
        int reserveGuardCount,
        String localDefenseRole,
        boolean localRoleAbilityUsed,
        int bulwarkCount,
        int marksmanCount,
        int engineerCount,
        int medicCount,
        int activeAssaultRaiders,
        int activeArcherRaiders,
        int activeSiegeRaiders,
        int activeInfiltratorRaiders,
        int activeCommanderRaiders,
        int activeBossRaiders,
        int activeEliteRaiders,
        int renown,
        int developmentPoints,
        int bossSigils,
        int victories,
        int defeats,
        int highestWave,
        int fortificationLevel,
        int logisticsLevel,
        int militiaLevel,
        int medicineLevel,
        boolean developmentResolved,
        boolean localDevelopmentVoteCast,
        int developmentVotes,
        int fortificationVotes,
        int logisticsVotes,
        int militiaVotes,
        int medicineVotes,
        String resolvedDevelopment,
        int lastRewardRenown,
        int lastRewardDevelopmentPoints,
        int lastRewardBossSigils,
        String lastOutcome,
        int lastCompletedWave,
        boolean voteOpen,
        int yesVotes,
        int noVotes,
        int requiredYesVotes,
        int voteSecondsRemaining,
        boolean anchorSet,
        int anchorX,
        int anchorY,
        int anchorZ,
        boolean raidActive,
        int raidSubwave,
        int raidSpawned,
        int raidDefeated,
        int raidBreached,
        int raidExpected,
        int raidEliteDefeated,
        boolean raidBossDefeated
) {
    private static final Gson GSON = new Gson();

    public static VillageSnapshot waiting() {
        return new VillageSnapshot(
                1, GamePhase.PREPARATION.name(), 1, "동기화 중", false, 1,
                120, 90, 55, 24,
                18, 72, 100, 100, 100,
                false, 100, 100, 100, 100, 0, 0,
                0, false, false, 0, 0, 0, 0,
                false, 0, DefenseDoctrine.BALANCED.name(), DefenseDoctrine.BALANCED.name(),
                0, 0, 0, 0, RaidForecast.EVEN.name(), 0, 0, 0, 0, 0,
                DefenseRole.UNASSIGNED.name(), false, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0,
                0, 0, 0, 0,
                false, false, 0, 0, 0, 0, 0, DevelopmentPath.NONE.name(),
                0, 0, 0, "NONE", 0,
                false, 0, 0, 1, 0,
                false, 0, 64, 0,
                false, 0, 0, 0, 0, 0, 0, false
        );
    }

    public String encode() {
        return GSON.toJson(this);
    }

    public static VillageSnapshot decode(String json) {
        try {
            VillageSnapshot snapshot = GSON.fromJson(json, VillageSnapshot.class);
            return snapshot == null ? waiting() : snapshot;
        } catch (JsonSyntaxException exception) {
            return waiting();
        }
    }

    public GamePhase gamePhase() {
        try {
            return GamePhase.valueOf(phase);
        } catch (IllegalArgumentException | NullPointerException exception) {
            return GamePhase.PREPARATION;
        }
    }

    public DefenseDoctrine activeDefenseDoctrine() {
        return DefenseDoctrine.parse(activeDoctrine);
    }

    public DefenseDoctrine leadingDefenseDoctrine() {
        return DefenseDoctrine.parse(leadingDoctrine);
    }

    public RaidForecast forecast() {
        try {
            return RaidForecast.valueOf(raidForecast);
        } catch (IllegalArgumentException | NullPointerException exception) {
            return RaidForecast.EVEN;
        }
    }

    public int raidResolved() {
        return raidDefeated + raidBreached;
    }

    public DefenseRole localRole() {
        return DefenseRole.parse(localDefenseRole);
    }

    public DevelopmentPath developmentPath() {
        return DevelopmentPath.parse(resolvedDevelopment);
    }

    public int activeRaiderCount() {
        return activeAssaultRaiders + activeArcherRaiders + activeSiegeRaiders
                + activeInfiltratorRaiders + activeCommanderRaiders + activeBossRaiders;
    }

    public int averageBuildingIntegrity() {
        return (townHallIntegrity + barracksIntegrity + storehouseIntegrity + infirmaryIntegrity) / 4;
    }

    public boolean lastNightVictory() {
        return "VICTORY".equals(lastOutcome);
    }

    public boolean lastNightDefeat() {
        return "DEFEAT".equals(lastOutcome);
    }
}
