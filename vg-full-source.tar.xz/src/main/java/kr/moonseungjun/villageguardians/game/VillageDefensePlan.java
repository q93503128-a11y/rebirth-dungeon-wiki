package kr.moonseungjun.villageguardians.game;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public record VillageDefensePlan(
        int day,
        DefenseDoctrine activeDoctrine,
        List<String> ballots,
        int northSpikeCharges,
        int southSpikeCharges
) {
    private static final Codec<DefenseDoctrine> DOCTRINE_CODEC = Codec.STRING.xmap(DefenseDoctrine::parse, DefenseDoctrine::name);
    public static final int MAX_SPIKE_CHARGES = 2;

    public static final Codec<VillageDefensePlan> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.INT.optionalFieldOf("day", 0).forGetter(VillageDefensePlan::day),
            DOCTRINE_CODEC.optionalFieldOf("active_doctrine", DefenseDoctrine.BALANCED).forGetter(VillageDefensePlan::activeDoctrine),
            Codec.STRING.listOf().optionalFieldOf("ballots", List.of()).forGetter(VillageDefensePlan::ballots),
            Codec.INT.optionalFieldOf("north_spike_charges", 0).forGetter(VillageDefensePlan::northSpikeCharges),
            Codec.INT.optionalFieldOf("south_spike_charges", 0).forGetter(VillageDefensePlan::southSpikeCharges)
    ).apply(instance, VillageDefensePlan::new));

    public VillageDefensePlan {
        day = Math.max(0, day);
        activeDoctrine = activeDoctrine == null ? DefenseDoctrine.BALANCED : activeDoctrine;
        ballots = List.copyOf(ballots);
        northSpikeCharges = clampCharges(northSpikeCharges);
        southSpikeCharges = clampCharges(southSpikeCharges);
    }

    public static VillageDefensePlan inactive() {
        return new VillageDefensePlan(0, DefenseDoctrine.BALANCED, List.of(), 0, 0);
    }

    public VillageDefensePlan forDay(int currentDay) {
        if (day == currentDay) return this;
        return new VillageDefensePlan(currentDay, activeDoctrine, List.of(), northSpikeCharges, southSpikeCharges);
    }

    public boolean hasVoted(UUID playerId) {
        String prefix = playerId + "|";
        return ballots.stream().anyMatch(ballot -> ballot.startsWith(prefix));
    }

    public VillageDefensePlan castVote(UUID playerId, DefenseDoctrine doctrine) {
        if (hasVoted(playerId)) return this;
        List<String> updated = new ArrayList<>(ballots);
        updated.add(playerId + "|" + doctrine.name());
        return new VillageDefensePlan(day, activeDoctrine, updated, northSpikeCharges, southSpikeCharges);
    }

    public int voteCount(DefenseDoctrine doctrine) {
        return (int) ballots.stream().filter(ballot -> doctrineOf(ballot) == doctrine).count();
    }

    public int voteCount(DefenseDoctrine doctrine, Set<UUID> eligiblePlayers) {
        if (eligiblePlayers == null || eligiblePlayers.isEmpty()) return 0;
        return (int) ballots.stream()
                .filter(ballot -> {
                    UUID voter = voterOf(ballot);
                    return voter != null && eligiblePlayers.contains(voter);
                })
                .filter(ballot -> doctrineOf(ballot) == doctrine)
                .count();
    }

    public int totalVotes() {
        return ballots.size();
    }

    public int totalVotes(Set<UUID> eligiblePlayers) {
        if (eligiblePlayers == null || eligiblePlayers.isEmpty()) return 0;
        return (int) ballots.stream()
                .map(VillageDefensePlan::voterOf)
                .filter(voter -> voter != null && eligiblePlayers.contains(voter))
                .count();
    }

    public DefenseDoctrine leadingDoctrine() {
        return DefenseVoteMath.resolve(
                voteCount(DefenseDoctrine.BALANCED),
                voteCount(DefenseDoctrine.NORTH_FOCUS),
                voteCount(DefenseDoctrine.SOUTH_FOCUS),
                voteCount(DefenseDoctrine.MOBILE_RESERVE)
        );
    }

    public DefenseDoctrine leadingDoctrine(Set<UUID> eligiblePlayers) {
        return DefenseVoteMath.resolve(
                voteCount(DefenseDoctrine.BALANCED, eligiblePlayers),
                voteCount(DefenseDoctrine.NORTH_FOCUS, eligiblePlayers),
                voteCount(DefenseDoctrine.SOUTH_FOCUS, eligiblePlayers),
                voteCount(DefenseDoctrine.MOBILE_RESERVE, eligiblePlayers)
        );
    }

    public VillageDefensePlan resolve() {
        return new VillageDefensePlan(day, leadingDoctrine(), ballots, northSpikeCharges, southSpikeCharges);
    }

    public VillageDefensePlan resolve(Set<UUID> eligiblePlayers) {
        DefenseDoctrine resolved = leadingDoctrine(eligiblePlayers);
        return new VillageDefensePlan(day, resolved, ballots, northSpikeCharges, southSpikeCharges);
    }

    public int spikeCharges(DefenseLane lane) {
        return lane == DefenseLane.NORTH ? northSpikeCharges : southSpikeCharges;
    }

    public VillageDefensePlan buildSpikeTrap(DefenseLane lane) {
        return lane == DefenseLane.NORTH
                ? new VillageDefensePlan(day, activeDoctrine, ballots, MAX_SPIKE_CHARGES, southSpikeCharges)
                : new VillageDefensePlan(day, activeDoctrine, ballots, northSpikeCharges, MAX_SPIKE_CHARGES);
    }

    public VillageDefensePlan consumeSpikeTrap(DefenseLane lane) {
        return lane == DefenseLane.NORTH
                ? new VillageDefensePlan(day, activeDoctrine, ballots, northSpikeCharges - 1, southSpikeCharges)
                : new VillageDefensePlan(day, activeDoctrine, ballots, northSpikeCharges, southSpikeCharges - 1);
    }

    public VillageDefensePlan restoreSpikeTrap(DefenseLane lane, int amount) {
        int restored = Math.max(0, amount);
        return lane == DefenseLane.NORTH
                ? new VillageDefensePlan(day, activeDoctrine, ballots, northSpikeCharges + restored, southSpikeCharges)
                : new VillageDefensePlan(day, activeDoctrine, ballots, northSpikeCharges, southSpikeCharges + restored);
    }

    private static UUID voterOf(String ballot) {
        int separator = ballot.indexOf('|');
        if (separator <= 0) return null;
        try {
            return UUID.fromString(ballot.substring(0, separator));
        } catch (IllegalArgumentException exception) {
            return null;
        }
    }

    private static DefenseDoctrine doctrineOf(String ballot) {
        int separator = ballot.indexOf('|');
        return separator < 0 ? DefenseDoctrine.BALANCED : DefenseDoctrine.parse(ballot.substring(separator + 1));
    }

    private static int clampCharges(int value) {
        return Math.max(0, Math.min(MAX_SPIKE_CHARGES, value));
    }
}
