package kr.moonseungjun.villageguardians.game;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

public record VillageResources(int food, int wood, int stone, int iron) {
    public static final Codec<VillageResources> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.INT.fieldOf("food").forGetter(VillageResources::food),
            Codec.INT.fieldOf("wood").forGetter(VillageResources::wood),
            Codec.INT.fieldOf("stone").forGetter(VillageResources::stone),
            Codec.INT.fieldOf("iron").forGetter(VillageResources::iron)
    ).apply(instance, VillageResources::new));

    public VillageResources {
        food = Math.max(0, food);
        wood = Math.max(0, wood);
        stone = Math.max(0, stone);
        iron = Math.max(0, iron);
    }

    public static VillageResources initial() {
        return new VillageResources(120, 90, 55, 24);
    }

    public boolean canAfford(int foodCost, int woodCost, int stoneCost, int ironCost) {
        return food >= Math.max(0, foodCost)
                && wood >= Math.max(0, woodCost)
                && stone >= Math.max(0, stoneCost)
                && iron >= Math.max(0, ironCost);
    }

    public VillageResources spend(int foodCost, int woodCost, int stoneCost, int ironCost) {
        if (!canAfford(foodCost, woodCost, stoneCost, ironCost)) {
            return this;
        }
        return new VillageResources(
                food - Math.max(0, foodCost),
                wood - Math.max(0, woodCost),
                stone - Math.max(0, stoneCost),
                iron - Math.max(0, ironCost)
        );
    }

    public VillageResources add(int foodGain, int woodGain, int stoneGain, int ironGain) {
        return new VillageResources(
                food + Math.max(0, foodGain),
                wood + Math.max(0, woodGain),
                stone + Math.max(0, stoneGain),
                iron + Math.max(0, ironGain)
        );
    }
}
