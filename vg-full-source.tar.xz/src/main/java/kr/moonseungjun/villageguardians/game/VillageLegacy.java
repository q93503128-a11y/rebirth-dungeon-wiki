package kr.moonseungjun.villageguardians.game;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

public record VillageLegacy(
        int renown,
        int developmentPoints,
        int bossSigils,
        int victories,
        int defeats,
        int highestWave,
        int fortificationLevel,
        int logisticsLevel,
        int militiaLevel,
        int medicineLevel,
        int lastRewardRenown,
        int lastRewardDevelopmentPoints,
        int lastRewardBossSigils,
        String lastOutcome,
        int lastCompletedWave
) {
    public static final int MAX_LEVEL = 5;

    public static final Codec<VillageLegacy> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.INT.optionalFieldOf("renown", 0).forGetter(VillageLegacy::renown),
            Codec.INT.optionalFieldOf("development_points", 0).forGetter(VillageLegacy::developmentPoints),
            Codec.INT.optionalFieldOf("boss_sigils", 0).forGetter(VillageLegacy::bossSigils),
            Codec.INT.optionalFieldOf("victories", 0).forGetter(VillageLegacy::victories),
            Codec.INT.optionalFieldOf("defeats", 0).forGetter(VillageLegacy::defeats),
            Codec.INT.optionalFieldOf("highest_wave", 0).forGetter(VillageLegacy::highestWave),
            Codec.INT.optionalFieldOf("fortification_level", 0).forGetter(VillageLegacy::fortificationLevel),
            Codec.INT.optionalFieldOf("logistics_level", 0).forGetter(VillageLegacy::logisticsLevel),
            Codec.INT.optionalFieldOf("militia_level", 0).forGetter(VillageLegacy::militiaLevel),
            Codec.INT.optionalFieldOf("medicine_level", 0).forGetter(VillageLegacy::medicineLevel),
            Codec.INT.optionalFieldOf("last_reward_renown", 0).forGetter(VillageLegacy::lastRewardRenown),
            Codec.INT.optionalFieldOf("last_reward_development_points", 0).forGetter(VillageLegacy::lastRewardDevelopmentPoints),
            Codec.INT.optionalFieldOf("last_reward_boss_sigils", 0).forGetter(VillageLegacy::lastRewardBossSigils),
            Codec.STRING.optionalFieldOf("last_outcome", "NONE").forGetter(VillageLegacy::lastOutcome),
            Codec.INT.optionalFieldOf("last_completed_wave", 0).forGetter(VillageLegacy::lastCompletedWave)
    ).apply(instance, VillageLegacy::new));

    public VillageLegacy {
        renown = Math.max(0, renown);
        developmentPoints = Math.max(0, developmentPoints);
        bossSigils = Math.max(0, bossSigils);
        victories = Math.max(0, victories);
        defeats = Math.max(0, defeats);
        highestWave = Math.max(0, highestWave);
        fortificationLevel = clampLevel(fortificationLevel);
        logisticsLevel = clampLevel(logisticsLevel);
        militiaLevel = clampLevel(militiaLevel);
        medicineLevel = clampLevel(medicineLevel);
        lastRewardRenown = Math.max(0, lastRewardRenown);
        lastRewardDevelopmentPoints = Math.max(0, lastRewardDevelopmentPoints);
        lastRewardBossSigils = Math.max(0, lastRewardBossSigils);
        lastOutcome = lastOutcome == null ? "NONE" : lastOutcome;
        lastCompletedWave = Math.max(0, lastCompletedWave);
    }

    public static VillageLegacy initial() {
        return new VillageLegacy(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "NONE", 0);
    }

    public int level(DevelopmentPath path) {
        return switch (path) {
            case FORTIFICATION -> fortificationLevel;
            case LOGISTICS -> logisticsLevel;
            case MILITIA -> militiaLevel;
            case MEDICINE -> medicineLevel;
            case NONE -> 0;
        };
    }

    public int upgradeCost(DevelopmentPath path) {
        int level = level(path);
        return path == DevelopmentPath.NONE || level >= MAX_LEVEL ? Integer.MAX_VALUE : ProgressionMath.upgradeCost(level);
    }

    public boolean canUpgrade(DevelopmentPath path) {
        return path != DevelopmentPath.NONE
                && level(path) < MAX_LEVEL
                && developmentPoints >= upgradeCost(path);
    }

    public VillageLegacy upgrade(DevelopmentPath path) {
        if (!canUpgrade(path)) return this;
        int cost = upgradeCost(path);
        return new VillageLegacy(
                renown,
                developmentPoints - cost,
                bossSigils,
                victories,
                defeats,
                highestWave,
                fortificationLevel + (path == DevelopmentPath.FORTIFICATION ? 1 : 0),
                logisticsLevel + (path == DevelopmentPath.LOGISTICS ? 1 : 0),
                militiaLevel + (path == DevelopmentPath.MILITIA ? 1 : 0),
                medicineLevel + (path == DevelopmentPath.MEDICINE ? 1 : 0),
                lastRewardRenown,
                lastRewardDevelopmentPoints,
                lastRewardBossSigils,
                lastOutcome,
                lastCompletedWave
        );
    }

    public VillageLegacy afterNight(
            boolean success,
            int completedWave,
            int defeatedRaiders,
            int breachedRaiders,
            int eliteDefeated,
            boolean bossDefeated
    ) {
        int rewardRenown = ProgressionMath.rewardRenown(
                success, completedWave, defeatedRaiders, eliteDefeated, bossDefeated
        );
        int rewardPoints = ProgressionMath.rewardDevelopmentPoints(success, completedWave, bossDefeated);
        int rewardSigils = success && bossDefeated ? 1 : 0;

        return new VillageLegacy(
                renown + rewardRenown,
                developmentPoints + rewardPoints,
                bossSigils + rewardSigils,
                victories + (success ? 1 : 0),
                defeats + (success ? 0 : 1),
                Math.max(highestWave, success ? completedWave : Math.max(0, completedWave - 1)),
                fortificationLevel,
                logisticsLevel,
                militiaLevel,
                medicineLevel,
                rewardRenown,
                rewardPoints,
                rewardSigils,
                success ? "VICTORY" : "DEFEAT",
                Math.max(1, completedWave)
        );
    }

    public int logisticsPercentBonus() {
        return logisticsLevel * 10;
    }

    public int extraGuards() {
        return ProgressionMath.extraGuards(militiaLevel);
    }

    public float fortificationDamageMultiplier() {
        return ProgressionMath.fortificationDamageMultiplier(fortificationLevel);
    }

    public int medicineResidentReduction() {
        return medicineLevel >= 4 ? 2 : medicineLevel >= 2 ? 1 : 0;
    }

    public int medicineMoraleReduction() {
        return medicineLevel * 2;
    }

    private static int clampLevel(int value) {
        return Math.max(0, Math.min(MAX_LEVEL, value));
    }
}
