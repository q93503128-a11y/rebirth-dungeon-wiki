package kr.moonseungjun.villageguardians.game;

public enum DefenseDoctrine {
    BALANCED("균형 방어", 1, 1, false),
    NORTH_FOCUS("북문 집중", 3, 1, false),
    SOUTH_FOCUS("남문 집중", 1, 3, false),
    MOBILE_RESERVE("기동 예비대", 1, 1, true);

    private final String displayName;
    private final int northWeight;
    private final int southWeight;
    private final boolean reserveEnabled;

    DefenseDoctrine(String displayName, int northWeight, int southWeight, boolean reserveEnabled) {
        this.displayName = displayName;
        this.northWeight = northWeight;
        this.southWeight = southWeight;
        this.reserveEnabled = reserveEnabled;
    }

    public String displayName() {
        return displayName;
    }

    public GuardDistribution distribute(int totalGuards) {
        int total = Math.max(0, totalGuards);
        int reserve = reserveEnabled && total >= 3 ? 1 : 0;
        int assignable = total - reserve;
        int totalWeight = northWeight + southWeight;
        int north = assignable * northWeight / totalWeight;
        int south = assignable - north;

        if (assignable > 0 && north == 0) {
            north = 1;
            south = Math.max(0, assignable - 1);
        }
        if (assignable > 1 && south == 0) {
            south = 1;
            north = assignable - 1;
        }
        return new GuardDistribution(north, south, reserve);
    }

    public static DefenseDoctrine parse(String raw) {
        try {
            return valueOf(raw);
        } catch (IllegalArgumentException | NullPointerException exception) {
            return BALANCED;
        }
    }

    public record GuardDistribution(int north, int south, int reserve) {
        public GuardDistribution {
            north = Math.max(0, north);
            south = Math.max(0, south);
            reserve = Math.max(0, reserve);
        }

        public int total() {
            return north + south + reserve;
        }
    }
}
