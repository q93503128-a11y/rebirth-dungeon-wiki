package kr.moonseungjun.villageguardians.game;

public final class RaidEscalationMath {
    private RaidEscalationMath() {}

    public static boolean isBossWave(int wave) {
        return wave > 0 && wave % 5 == 0;
    }

    public static boolean shouldSpawnElite(int wave, int subwave, int spawnIndex) {
        if (wave < 2 || spawnIndex <= 0) return false;
        int interval = Math.max(4, 8 - Math.max(0, wave) / 2);
        return spawnIndex % interval == 0 || (subwave >= 3 && spawnIndex % 5 == 0);
    }

    public static int eliteVariantIndex(int wave, int subwave, int spawnIndex) {
        return Math.floorMod(wave + subwave + spawnIndex, 3);
    }

    public static boolean enraged(float health, float maxHealth) {
        return maxHealth > 0.0F && health <= maxHealth * 0.5F;
    }
}
