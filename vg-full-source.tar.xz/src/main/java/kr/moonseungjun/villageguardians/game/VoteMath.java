package kr.moonseungjun.villageguardians.game;

public final class VoteMath {
    private VoteMath() {}

    /** Strict majority. 1/1, 2/2, 2/3, 3/4, 3/5, 4/6. */
    public static int requiredYesVotes(int eligiblePlayers) {
        if (eligiblePlayers < 1) {
            throw new IllegalArgumentException("eligiblePlayers must be at least 1");
        }
        return eligiblePlayers / 2 + 1;
    }

    public static VoteResult evaluate(int eligiblePlayers, int yesVotes, int noVotes) {
        if (yesVotes < 0 || noVotes < 0 || yesVotes + noVotes > eligiblePlayers) {
            throw new IllegalArgumentException("invalid vote counts");
        }
        int required = requiredYesVotes(eligiblePlayers);
        if (yesVotes >= required) {
            return VoteResult.PASSED;
        }
        if (noVotes >= required || yesVotes + noVotes >= eligiblePlayers) {
            return VoteResult.REJECTED;
        }
        return VoteResult.PENDING;
    }
}
