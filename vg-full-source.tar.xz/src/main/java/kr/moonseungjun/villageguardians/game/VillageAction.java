package kr.moonseungjun.villageguardians.game;

public enum VillageAction {
    REQUEST_STATE,
    PROPOSE_NIGHT,
    VOTE_YES,
    VOTE_NO,
    SET_ANCHOR,
    GENERATE_VILLAGE,
    REPAIR_NORTH_GATE,
    REPAIR_SOUTH_GATE,
    REPAIR_WALL,
    REPAIR_BUILDINGS,
    BUILD_NORTH_BARRICADE,
    BUILD_SOUTH_BARRICADE,
    BUILD_NORTH_SPIKES,
    BUILD_SOUTH_SPIKES,
    DEFENSE_BALANCED,
    DEFENSE_NORTH_FOCUS,
    DEFENSE_SOUTH_FOCUS,
    DEFENSE_MOBILE_RESERVE,
    ROLE_BULWARK,
    ROLE_MARKSMAN,
    ROLE_ENGINEER,
    ROLE_MEDIC,
    USE_ROLE_ABILITY,
    DEVELOPMENT_FORTIFICATION,
    DEVELOPMENT_LOGISTICS,
    DEVELOPMENT_MILITIA,
    DEVELOPMENT_MEDICINE,
    WORK_HARVEST,
    WORK_LOGISTICS,
    WORK_MEDICAL,
    WORK_DRILL;

    public static VillageAction parse(String raw) {
        try {
            return valueOf(raw);
        } catch (IllegalArgumentException exception) {
            return REQUEST_STATE;
        }
    }
}
